<?php 
    define("KEY","granjaavicola1926");//Llave que permite la encriptación. 
    define("METODO","AES-128-ECB");//Método de encriptación.
    //Esta clase se encarga de darnos acceso a la base de datos, en caso de que en un futuro cambiemos de servidor, cambiamos estos valores.
    define("Servidor","localhost");
    define("Usuario","root");
    define("Password","");
    define("BaseDatos","granjaavicola");
?>